<template>
  <div>
    <div class='mb-32 toolbar'>
      <Navbar2/> 
    </div>
    <Nuxt />
    <div>
      <Footer/>
    </div>
  </div>
</template>

<script>
import Navbar2 from '../components/Navbar2';
import Footer from '../components/Footer';
export default {
  components:{
    Navbar2,
    Footer
  }
}
</script>

<style scoped lang="scss">
*{
  color:#444B54;
}
.toolbar{
  transition: All 0.7s;
}

</style>
