<template> 
<div>
    <div class="flex justify-between items-center containeur fixed">
      <!-- component -->

<div class="w-full text-gray-700 bg-white ">
  <div class="flex flex-col max-w-screen-xl px-4 mx-auto md:items-center md:justify-between md:flex-row md:px-6 lg:px-8">
    <div class="p-4 flex flex-row items-center justify-between">
      <img src="../assets/img/logo.png" width="120px" alt="logo">
      <button class="md:hidden rounded-lg focus:outline-none focus:shadow-outline">
        
      </button>
    </div>
    <nav class="flex-col flex-grow pb-4 md:pb-0 hidden md:flex md:justify-end md:flex-row">
      <a class="px-4 py-2 mt-2 text-sm font-semibold bg-transparent rounded-lg md:mt-0 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none" href="#">Nos services de montage</a>
      <a class="px-4 py-2 mt-2 text-sm font-semibold bg-transparent rounded-lg md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none " href="#">Qui sommes nous ?</a>
      <a class="px-4 py-2 mt-2 text-sm font-semibold bg-transparent rounded-lg md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none " href="#">Actualités</a>
      <a class="px-4 py-2 mt-2 text-sm font-semibold bg-transparent rounded-lg md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none " href="#">Contact</a>
      <div class="relative">
        <button class="flex flex-row items-center w-full px-4 py-2 mt-2 text-sm font-semibold text-left bg-yellow-500 rounded-lg md:w-auto md:inline md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-yellow-600 focus:outline-none">
        Connexion</button>
        
      </div>    
    </nav>
  </div>
</div>
  </div>
</div>
  
</template>

<script>
export default {
  mounted() {
    window.addEventListener("DOMContentLoaded", () => {
      let conteneur = document.querySelector(".containeur");
      window.addEventListener("scroll", () => {
        if (window.scrollY > 0) {
          conteneur.style.boxShadow = "0 5px 5px rgba(0,0,0,0.5)";
        } else {
          conteneur.style.boxShadow = "";
        }
      });
    });
  },
};
</script>

<style scoped lang="scss">
.containeur {
  font-family: "Roboto", sans-serif;
  box-sizing: border-box;
  width: 100%;
  height: auto;
  transition: All 0.7s;

  &.fixed {
    position: fixed;
    background: white;
    top: 0;
    left: 0;
    right: 0;
    transition: All 0.7s;
    z-index: 50;
    height: 8%;
  }
  .img {
    width: 15%;
    img {
      width: 150px;
      margin: 25px 50px;
    }
  }
  .nav {
    width: 70%;
    ul {
      li {
        color: #af8f0b;
        font-size: clamp(1rem, 1.4vw, 1.5rem);
        &:hover {
          color: #796206;
        }

        button {
          background: #f1c40f;
        }
        button:hover {
          background-color: #dcb51c;
        }
      }
    }
  }
}
</style>