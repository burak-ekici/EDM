<template>
  <div>
      <div class="conteneur flex flex-col justify-center align-center">
          <h1 class="text-4xl font-bold text-center">Retrouvez toute notre actualité</h1>
          <hr>
          <div class="mx-auto"> <button class="button-etape hover:bg-yellow-600 mt-10 rounded px-4 py-3 text-2xl font-bold leading-6 text-center text-white text-lg transition shadow focus:outline-none hover:shadow-lg">Actualités</button></div>
         
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
    h1{
        font-family: "M PLUS Rounded 1c", sans-serif;
    }
    .conteneur{
        height:500px;
    }
    hr{
        width:10%;
        color:gray;
        margin:0 auto;
        border:1px solid gray;
        background:gray;
        margin-top:15px;
    }
    .button-etape{
  background:#21327D;
  color:white;
}
.button-etape:hover{
  background:#18245b;
}
</style>