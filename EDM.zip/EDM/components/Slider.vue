<template>
<div class="mt-64 relative">
    
    <h1 class="mb-4 block text-4xl font-bold">Prestation</h1>
    <v-app class="slider">
      <v-main class='h-full' >
          <v-carousel cycle hide-delimiters height="650px" class="elevation-20">
            <v-carousel-item  class="h-full"
            v-for="(item,i) in items"
            :key="i"
            :src="item.src"
            
            >
             <v-sheet  class="grey--text grey lighten-2 pl-4 py-3 font-bold text-xl" >
               {{item.title}}
             </v-sheet>
      
            </v-carousel-item>
            
        </v-carousel>
      </v-main>
  </v-app>
  
</div>
  
</template>

<script>


  export default {
    data () {
      return {
        items: [
          {
            src: require('../assets/img/collectivite.jpeg'),
            title: 'Mobilier pour collectivités'
          },
          
          {
            src: require('../assets/img/abri.jpeg'),
            title: 'Abri de jardin'
          },
          {
            src: require('../assets/img/ecole.jpeg'),
            title: 'Mobilier universitaire'
          },
          {
            src: require('../assets/img/racks.jpeg'),
            title: 'Racks et rayonnages'
          },
          {
            src: require('../assets/img/hopital.jpeg'),
            title: 'Mobilier pour collectivités'
          },
          {
            src: require('../assets/img/salon.jpeg'),
            title: "Aménagement de mobilier d'intérieur"
          },
          {
            src: require('../assets/img/jeux.jpeg'),
            title: 'Aménagement extérieur'
          }
          
        ],
        
      }
    },
    
  }
</script>

<style scoped>

h1{
  margin-top:-100px;
  margin-left:50px;
  font-family: 'Raleway', sans-serif;
}




</style>