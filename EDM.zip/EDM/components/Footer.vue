<template>
  <div class="footer pl-16 pt-16">
      <div class="pl-6 ">
          <img src="../assets/img/logo.png" alt="">
      </div>
      <div class="text-white w-1/3  pt-6">
          <p class="font-bold">EXPERTS DU MONTAGE est LE service de pose de mobilier en B2B, qui travaille sur l'ensemble de la France et tout le Bénélux francophone.</p>
          <p class="pt-4">Nous travaillons avec de nombreux fournisseurs de mobilier et de rayonnages, des agenceurs, des architectes d’intérieurs et des revendeurs régionaux. Nous gérons la   pose et le montage de leurs produits directement chez leurs clients.</p>
          <p class="pt-4">Pour ces interventions, nous faisons intervenir des partenaires professionnels locaux, spécialisés
            dans le montage de mobilier, notés et recommandés par nos clients.</p>
      </div>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.footer{
    background:#3A4888;
    height:500px;
    font-family: "M PLUS Rounded 1c", sans-serif;
}

</style>