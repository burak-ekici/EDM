<template>
  <div>
    <div class="polygon-shadow">
      <div class="polygon">
        <div class="h-screen">
          <h1 class="block text-center font-bold titre-principal mb-20">
            <span class="majuscule">D</span>éroulement
          </h1>
          <div>
            <div class="flex flex-wrap flex-row grid">
              <!-- card 1  -->
              <div
                class="bg-white rounded text-black p-5 flex flex-col items-center card1"
              >
                <div class="w-full flex flex-col justify-center">
                  <div class="w-full flex justify-center items-center">
                    <span class="number mb-6">1</span>
                  </div>
                  <h1
                    class="titre-carte1 text-center text-lg text-blue-700 font-bold"
                  >
                    Definition du besoin sur votre interface dédiée
                  </h1>
                </div>
                <div class="w-full pl-6 pt-6 flex justify-center pb-6 pr-6">
                  <img width="100px" src="../assets/img/liste.svg" alt="" />
                </div>

                <div class="w-full pt-6 font-bold">
                  <ul class="liste1 space-y-2 text-center">
                    <li>Descriptif guidé</li>
                    <li>Nombre de piéces à monté</li>
                    <li>Rajout de fichiers, photos, vidéos</li>
                    <li>Choix de la date de montage</li>
                    <li>Si besoin, brief personalisée</li>
                  </ul>
                </div>
              </div>
              <!-- card 1  -->
              <!-- <img class='fleche1' src="../assets/img/fleche-droite.svg" alt=""> -->
              <!-- card 2   -->
              <div
                class="bg-white rounded text-black p-5 flex flex-col items-center card2"
              >
                <div class="w-full flex flex-col justify-center">
                  <div class="w-full flex justify-center items-center">
                    <span class="number mb-6">2</span>
                  </div>
                  <h1
                    class="titre-carte1 text-center text-lg text-blue-700 font-bold"
                  >
                    Envoie à nos monteurs compétent de la région
                  </h1>
                </div>
                <div class="w-full pl-6 pt-6 flex justify-center pb-6 pr-6">
                  <img width="100px" src="../assets/img/transfert.svg" alt="" />
                </div>

                <div class="w-full pt-6 font-bold">
                  <ul class="liste1 space-y-2 text-center">
                    <li>Coordination par notre équipe</li>
                    <li>Suivi de chaque étape sur votre interface</li>
                  </ul>
                </div>
              </div>
              <!-- card 2   -->
              
              
              <!-- card 3  -->
              <div
                class="bg-white rounded text-black p-5 flex flex-col items-center card3"
              >
                <div class="w-full flex flex-col justify-center">
                  <div class="w-full flex justify-center items-center">
                    <span class="number mb-6">3</span>
                  </div>
                  <h1
                    class="titre-carte1 text-center text-lg text-blue-700 font-bold"
                  >
                    Devis établi sur la base du brief
                  </h1>
                </div>
                <div class="w-full pl-6 pt-6 flex justify-center pb-6 pr-6">
                  <img width="100px" src="../assets/img/devis.svg" alt="" />
                </div>

                <div class="w-full pt-6 font-bold">
                  <ul class="liste1 space-y-2 text-center">
                    <li>Sélection du meilleure devis par la plateforme</li>
                    <li>
                      Tarif horaire d'installation ou tarif à la piéce si
                      interventions récurrentes
                    </li>
                    <li>Go / No Go du devis</li>
                  </ul>
                </div>
              </div>
              <!-- card 3  -->
              
              <!-- card 4  -->
              <div
                class="bg-white rounded text-black p-5 flex flex-col items-center card4"
              >
                <div class="w-full flex flex-col justify-center">
                  <div class="w-full flex justify-center items-center">
                    <span class="number mb-6">4</span>
                  </div>
                  <h1
                    class="titre-carte1 text-center text-lg text-blue-700 font-bold"
                  >
                    Planification de l'intervention
                  </h1>
                </div>
                <div class="w-full pl-6 pt-6 flex justify-center pb-6 pr-6">
                  <img width="100px" src="../assets/img/calendar.svg" alt="" />
                </div>

                <div class="w-full pt-6 font-bold">
                  <ul class="liste1 space-y-2 text-center">
                    <li>Confirmation du devis pré établi</li>
                    <li>
                      Confirmation du jour de l'intervention et de l'horaire de
                      reception du mobilier
                    </li>
                  </ul>
                </div>
              </div>
              <!-- card 4  -->
              <!-- <img class='fleche4' src="../assets/img/dotted-line-left.svg" alt=""> -->
              <!-- card 5  -->
              <div
                class="bg-white rounded text-black p-5 flex flex-col items-center card5"
              >
                <div class="w-full flex flex-col justify-center">
                  <div class="w-full flex justify-center items-center">
                    <span class="number mb-6">5</span>
                  </div>
                  <h1
                    class="titre-carte1 text-center text-lg text-blue-700 font-bold"
                  >
                    Execution de la prestation
                  </h1>
                </div>
                <div class="w-full pl-6 pt-6 flex justify-center pb-6 pr-6">
                  <img width="100px" src="../assets/img/outils.svg" alt="" />
                </div>

                <div class="w-full pt-6 font-bold">
                  <ul class="liste1 space-y-2 text-center"></ul>
                </div>
              </div>
              <!-- card 5  -->
              <!-- <img class='fleche5' src="../assets/img/dotted-line-right.svg" alt=""> -->
              <!-- card 6  -->
              <div
                class="bg-white rounded text-black p-5 flex flex-col items-center card6"
              >
                <div class="w-full flex flex-col justify-center">
                  <div class="w-full flex justify-center items-center">
                    <span class="number mb-6">6</span>
                  </div>
                  <h1
                    class="titre-carte1 text-center text-lg text-blue-700 font-bold"
                  >
                    Notation de la prestation
                  </h1>
                </div>
                <div class="w-full pl-6 pt-6 flex justify-center pb-6 pr-6">
                  <img width="100px" src="../assets/img/star.svg" alt="" />
                </div>

                <div class="w-full pt-6 font-bold">
                  <ul class="liste1 space-y-2 text-center">
                    <li>Débrief avec photo et bon d'intervention signé</li>
                    <li>
                      Rappel du client final pour évalution de la prestation
                    </li>
                    <li>Facturation depuis la plateforme</li>
                  </ul>
                </div>
              </div>
              <!-- card 6  -->
            </div>

            <!-- text de fin  -->
            <div class="div7 text-2xl text-center font-bold p-20">
              <img class="main" src="../assets/img/main.svg" alt="" />
              <p class="mb-6">
                <span class="text-maj">N</span>ous travaillons avec de nombreux
                fournisseurs de mobilier, de rayonnages, des agenceurs, des
                architectes d’intérieurs et des revendeurs régionaux. Nous
                gérons la pose et le montage de leurs produits directement chez
                leurs clients.
              </p>

              <p class="p-6">
                Pour ces interventions, nous faisons intervenir des partenaires
                professionnels locaux, spécialisés dans le montage de mobilier,
                notés et recommandés par nos clients.
              </p>

              <button
                class="button-etape hover:bg-yellow-600 mt-6 rounded px-6 py-3 text-xl font-bold leading-6 text-center text-white text-lg transition shadow focus:outline-none hover:shadow-lg"
              >
                Demander un devis
              </button>
            </div>
            <!-- text de fin  -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 100px;
}
.button-etape {
  background: #f8de36;
  color: black;
}
.button-etape:hover {
  background: #bbac46;
}
.div7 {
  width: 100%;

  color: #5482d1;
  font-family: "M PLUS Rounded 1c", sans-serif;
}
.div7 .text-jaune {
  color: #ffe43b;
  font-size: 1.7rem;
}
.div7 .text-maj {
  font-size: 3rem;
}
.div7 .text-maj2 {
  font-size: 1.8rem;
  color: #ffe43b;
}
.fleche1 {
  filter: invert(48%) sepia(29%) saturate(1066%) hue-rotate(179deg)
    brightness(90%) contrast(98%);
  position:absolute;
  left:48.5%;
  top:20%;
  width:50px;
}
.fleche2 {
  filter: invert(48%) sepia(29%) saturate(1066%) hue-rotate(179deg)
    brightness(90%) contrast(98%);
  position:absolute;
  left:70%;
  top:32.5%;
  width:82px;
  
}
.start {
  height: 200px;
  top: 23%;
  left: 25%;
  width: 100%;
  position: absolute;
  z-index: -2;
  transform: scale(1.8);
}
.fleche3 {
  filter: invert(48%) sepia(29%) saturate(1066%) hue-rotate(179deg)
    brightness(90%) contrast(98%);
  position:absolute;
  left:48.5%;
  top:42.5%;
  width:50px;
}
.fleche4 {
  filter: invert(48%) sepia(29%) saturate(1066%) hue-rotate(179deg)
    brightness(90%) contrast(98%);
  height: 200px;
  top: 320%;
  left: -1%;
  width: 100%;
  position: absolute;
  z-index: -2;
  transform: scale(1.8);
}
.fleche5 {
  filter: invert(48%) sepia(29%) saturate(1066%) hue-rotate(179deg)
    brightness(90%) contrast(98%);
  height: 200px;
  top: 400%;
  left: -1%;
  width: 100%;
  position: absolute;
  z-index: -2;
  transform: scale(1.8);
}
.main {
  height: 200px;
  width: 100%;
}
.card1 {
  width: 100%;
  height: 100%;
}
.card2 {
  width: 100%;
  height: 100%;
}
.card3 {
  width: 100%;
  height: 100%;
}
.card4 {
  width: 100%;
  height: 100%;
}
.card5 {
  width: 100%;
  height: 100%;
}
.card6 {
  width: 100%;
  height: 100%;
}
.titre-principal {
  font-size: clamp(1.3rem, 4vw, 6rem);
}
.titre-carte1 {
  font-size: clamp(0.6rem, 1.5vw, 2.5rem);
}
.liste1 {
  font-size: clamp(0.6rem, 1.5vw, 2.5rem);
}
.number {
  font-size: clamp(1rem, 3vw, 6rem);
  color: #ffe43b;
  background-color: #21327d;
  display: flex;
  width: 60px;
  height: 60px;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
}
.polygon {
  background-image: radial-gradient(circle at 59% 30%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 3%,transparent 3%, transparent 100%),radial-gradient(circle at 78% 41%, rgba(255,255,255,0.01) 0%, rgba(255,255,255,0.01) 3%,transparent 3%, transparent 100%),radial-gradient(circle at 15% 80%, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.02) 3%,transparent 3%, transparent 100%),radial-gradient(circle at 45% 43%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 3%,transparent 3%, transparent 100%),radial-gradient(circle at 63% 9%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 7%,transparent 7%, transparent 100%),radial-gradient(circle at 71% 80%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 7%,transparent 7%, transparent 100%),radial-gradient(circle at 19% 0%, rgba(255,255,255,0.01) 0%, rgba(255,255,255,0.01) 7%,transparent 7%, transparent 100%),radial-gradient(circle at 62% 12%, rgba(255,255,255,0.01) 0%, rgba(255,255,255,0.01) 7%,transparent 7%, transparent 100%),radial-gradient(circle at 46% 76%, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.02) 7%,transparent 7%, transparent 100%),radial-gradient(circle at 59% 41%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 7%,transparent 7%, transparent 100%),radial-gradient(circle at 4% 53%, rgba(255,255,255,0.01) 0%, rgba(255,255,255,0.01) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 16% 40%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 94% 48%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 47% 6%, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.02) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 64% 65%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 58% 40%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 37% 3%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 42% 50%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 5%,transparent 5%, transparent 100%),radial-gradient(circle at 21% 78%, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.03) 5%,transparent 5%, transparent 100%),linear-gradient(135deg, rgb(58,72,136),hsla(218,81%,39%,1));
  width: 100%;
  box-shadow: 3px -1px 3px black;
  height: 2900px;
  padding: 120px 170px;
  color: white;
}
.polygon-shadow {
  filter: drop-shadow(0 0 0.3rem rgb(23, 23, 23));
}
.polygon .titre-principal {
  font-family: "M PLUS Rounded 1c", sans-serif;
  z-index: 50;
  position: relative;
  background: linear-gradient(
    130deg,
    rgb(255, 247, 6) 0%,
    rgb(248, 214, 20) 100%
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.majuscule {
  color: #d0ab1a;
  font-size: clamp(2rem, 6vw, 6rem);
}
</style>