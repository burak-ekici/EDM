<template>
    <div class='relative conteneur-principal'>
        <div class='h-screen fond mt-32 flex justify-between p-32 items-center bg-yellow-500'>
            <img class="img2" src="../assets/img/form1.svg" alt="">
            <img class="img1" src="../assets/img/like.svg" alt="">
        </div>
        <div class='conteneur-text absolute top-0 left-0 w-full flex-col h-full flex justify-center items-center'>
            <h1 class='titre text-black text-5xl font-bold w-1/2 text-center mb-6'>Vous êtes monteur professionnel de mobilier ?</h1>
            <p class="text-black text-center text-3xl w-1/2 mb-6">Vous souhaitez rejoindre la communauté des Experts du Montage ?</p>
            <p class='w-1/3  text-black text-center text-3xl mb-10'>Pour que nous puissions travailler ensemble, merci de compléter le
            questionnaire ci-dessous.</p>
            <button class="px-16 py-6 font-bold text-2xl font-medium leading-6 text-center text-yellow-500 uppercase transition bg-blue-600 shadow focus:outline-none hover:shadow-lg  hover:bg-blue-700">REMPLIR LE FORMULAIRE</button>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.conteneur-principal{
    background:blue;
    width:100%;
}
.img1{
    width:200px;
    position:relative;
    z-index:20;
}

.img2{
    width:200px;
    position:relative;
    z-index:20;
}
.titre{
    line-height: 3.5rem;;
}
.conteneur-text{
    line-height: 2.5rem;
    z-index:5;
}

.fond:after{
    position:absolute;
    bottom:0;
    right:0;
    content:'';
    background:white;
    height:100%;
    width:100%;
    clip-path: polygon(50% 100%,100% 0%,100% 100%);
    background-color:#394888;
}

p{
   font-family: "M PLUS Rounded 1c", sans-serif;
}
</style>