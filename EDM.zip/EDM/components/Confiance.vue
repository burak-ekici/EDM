<template>
  <div class='mt-20'>
      <h1 class="titre-principal text-4xl font-bold text-center p-20">ILS NOUS FONT CONFIANCE</h1>
      <div class='flex flex-row justify-center flex-wrap conteneur-principal'>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/asetam.png" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/chalet.png" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/desk.png" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/espacebureau.png" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/leroy-merlin.png" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/letaneur.png" alt="">
          </div>
          <div class="conteneur">
               <img class='logo' src="../assets/img/logo/mibibam.jpg" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/mob.png" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/permanence.png" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/pickawood.png" alt="">
          </div>
          
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/sephora.png" alt="">
          </div>
          <div class="conteneur black">
              <img class='logo' src="../assets/img/logo/tikimob.jpg" alt="">
          </div>
          <div class="conteneur">
              <img class='logo' src="../assets/img/logo/zara.jpg" alt="">
          </div>
      </div>
      
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.titre-principal{
    color:#9f9f9f;
    position:relative;
}
.titre-principal:before{
    content:'';
    height:3px;
    width:20%;
    background: #f2b600;
    position:absolute;
    top:108px;
    left:10%;
    border-radius: 50%;
}
.titre-principal:after{
    content:'';
    height:3px;
    width:20%;
    background: #f2b600;
    position:absolute;
    top:108px;
    left:70%;
    border-radius: 50%;
}
.conteneur{
    width:175px;
    height:175px;
    border-radius:50%;
    background:white;
    display:flex;
    justify-content: center;
    align-items: center;
    box-shadow: 2px 2px 4px rgb(128, 128, 128);
    margin:20px 30px;
    transition:0.5s all;
    user-select:none;
}
.conteneur:hover{
    transform:translateY(20px);
    
}
.logo{
    width:100px;
    pointer-events: none;
}
.black{
    background:black;
}

</style>