<template>
  <div class="containeur flex justify-center mt-20 flex-col">
    <div>
      <p class="text-4xl titre font-bold">
        <i class="fas fa-trophy"></i><span class="number">1</span> ère plateforme
        web de montage de mobilier
      </p>
    </div>
    <div class="img">
      <img src="../assets/img/banniere.png" alt="" />
    </div>
    <div class="phrase2 -mt-20">
      <p class="text-lg">
        <i class="fas fa-map-marked"></i>Nous intervenons sur l’ensemble de la
        France et tout le
        Bénélux francophone
      </p>
    </div>
    <div class="w-full flex justify-center mt-8">
        <button class="boutton2 rounded px-8 py-4 text-lg font-bold leading-6 text-center text-white text-lg transition shadow focus:outline-none hover:shadow-lg">Contactez nous</button>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped lang="scss">
.boutton2{
  background-color:#3A4888; 
}
.boutton2:hover{
    background-color:#2a335d; 
}
.containeur {
  width: 100%;
  .img {
    height: 350px;
    margin-top: 0px;
    img {
      width: 70%;
      margin: 0 auto;
    }
  }

  div {
    
    .titre:after {
      content: "";
      display: block;
      background: #3a4888;
      height: 5px;
      width: 60%;
      transform: skew(-280deg);
      margin: 0 auto;
    }
    p {
      width: 60%;
      display: block;
      margin: 0px auto;
      text-align: center;
      font-family: "Raleway", sans-serif;
      font-weight: 900;

      i {
        margin-right: 15px;
        color: #ebd634;
      }
    }
  }
  .phrase2 {
    p {
      display: block;
      width: 40%;
      font-size: 1.5rem;
      i {
        font-size: 2rem;
        color: #3a4888;
      }
      .france {
        color: #f1c40f;
      }
      .benelux {
        color: #f1c40f;
      }
    }
  }
}
</style>